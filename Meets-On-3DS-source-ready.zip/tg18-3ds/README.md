# Meets On 3DS

This frontend contains the targeted native-rate audio correction on top of the
faster cleaned build. Its sibling `../tg18-emu-main/core` is included in the
complete bundle and is byte-identical to the supplied locally patched core.

Build with your existing Mac Rust nightly/devkitPro installation:

```bash
cd ~/Desktop/tg18-3ds
PATH="/opt/devkitpro/tools/bin:$PATH" bash build.sh
```

Outputs are `READY_FOR_FTPD/tg18-3ds.3dsx` and `tg18-3ds.smdh` in that folder.
This source ZIP contains no freshly compiled or historical binary.

The bundle's root README contains backup/replacement steps, exact Mac commands,
FTPD transfer guidance and a hardware listening checklist. Read
`docs/audio-fix-report.md` for the audio diagnosis and verification. Earlier
cleanup documents remain as historical context; this report describes the
current audio implementation.

## Current layout

- `src/audio.rs`: native-rate PCM renderer and bounded FIFO.
- `src/main.rs`: app loop and NDSP output adapter.
- `src/lcd.rs`: retained faster LCD renderer.
- `src/firmware_picker.rs`, `photo.rs`, `diagnostics.rs`: retained modules.
- `assets/runtime/`: all 53 original embedded runtime assets.
- `assets/artwork/`: supplied editable artwork.
- `tools/`: current validation, launcher metadata and guarded core patch tools.
- `tests/`: host regressions, real-core audio reproducer and original LCD reference.
- `docs/`: reports, source checksums and reviewable diffs.

No romfs/ directory or duplicate asset packaging is used. Firmware filenames,
SD paths, per-firmware save compatibility, cheats, stereo graphics, 3D Camera
screenshots and diagnostics controls remain as before.

## Build options

```bash
bash build.sh                         # incremental release build
bash build.sh --clean                 # explicit cache clean
bash build.sh --no-core-patch         # don't edit a compatible core
bash build.sh --check --no-core-patch  # compile check without staging outputs
bash build.sh --audio-debug           # optional counters saved once at exit
```

The guarded v49 core patch is still recognized as already installed in the
provided core. Unknown or partial revisions stop rather than being overwritten.
The app lockfile and dependency versions are unchanged. Python 3.11+ is needed
by the validators; build.sh selects a compatible installed interpreter. Your
Homebrew Python 3.12 is supported. Set TG18_PYTHON to an interpreter path to
override selection.

## Host verification

```bash
python3 tools/validate.py --check-core
python3 -m unittest discover -s tests -p 'test_*.py' -v
cargo test --manifest-path tests/host/Cargo.toml --release --locked
cargo run --manifest-path tests/host/Cargo.toml --release --locked --bin audio-reproduction
```

The Python pipeline tests mock compiler/devkit commands. Rust host tests use
the supplied real core and test PCM timing, buffering, renderer equivalence,
photos and diagnostics. Neither replaces a fresh 3DS build and hardware test.
